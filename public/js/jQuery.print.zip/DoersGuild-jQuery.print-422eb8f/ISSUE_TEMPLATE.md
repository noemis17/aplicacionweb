### Expected behaviour

### Observed behaviour

### Steps to reproduce the issue

### Simplified demo link reproducing the issue

### jQuery, jQuery.print version

### Browser and operating system
